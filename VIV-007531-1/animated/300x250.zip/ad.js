//----------------------------------------------
// Ad
//----------------------------------------------
var adWidth           = 300;
var adHeight          = 250;
var count             = 0;
var sheenable         = true; // Set to 'true' to enable rollover effect.
var isi               = null;
var autoScrollSpeed   = 750000;
var autoScrollOffset  = 0;

// For Testing run time
var duration          = 0;
var durationInterval;
var ALLOW_AUTO_SCROLL = true;
var CURRENT_PLAY_COUNT = 1;
var TOTAL_PLAY_COUNT = 3;
var SHOW_CONSOLE_LOGS = true;
var SCENE_TIMELINES = [];
var TOTAL_SCENE_COUNT = 3;
var MASTER_TIMELINE = null;

//----------------------------------------------
// ClickTags
//----------------------------------------------
var clickTag1Label = 'Main Exit';
var clickTag1URL = "https://www.vivitrolhcp.com/dosing-and-pharmacokinetics";

var clickTag2Label = 'Prescribing Information';
var clickTag2URL = "https://labeling.alkermes.com/uspi_vivitrol.pdf";


//----------------------------------------------
// Config
//----------------------------------------------
function buildVars() {
  var elements = document.getElementsByTagName("*");

  for (var i = 0, elementsLength = elements.length; i < elementsLength; i++) {
   var element = elements[i];
   if (element.id) {
      // `element.id.toString()` because IE is stupid.
      window[(element.id.toString())] = element;
    }
  }
}

//----------------------------------------------
// Link / Click-Out Methods
//----------------------------------------------
function stopAutoScroll(event) {
  if(ALLOW_AUTO_SCROLL) {
    var currentScrollPosition = getTranslateY(scrollerContent);
    isi.scrollTo(0, currentScrollPosition, 0, {
      // simple linear easing function
      style: 'cubic-bezier(0,0,1,1)',
      fn: function (k) { return k; }
    });
  }
  ALLOW_AUTO_SCROLL = false;
}


function addListeners() {
  overlayButton.addEventListener('click', exit1ClickHandler, false);
  piLink.addEventListener('click', exit2ClickHandler, false);
  piLink2.addEventListener('click', exit2ClickHandler, false);
  // medLink.addEventListener('click', exit3ClickHandler, false);

  // Disables autoscroll when the user mouses over the content
  // scrollerContainer.addEventListener("mouseover", stopAutoScroll);

  isi.on('scrollStart', stopAutoScroll);

  scrollerContainer.addEventListener("touchstart", stopAutoScroll);
  scrollerContainer.addEventListener("touchmove", stopAutoScroll);
  // scrollerContainer.addEventListener("touchend", stopAutoScroll);
  scrollerContainer.addEventListener("click", stopAutoScroll);

  var scroller = document.querySelector('.iScrollIndicator');
  if(scroller) {
    scroller.addEventListener("touchstart", stopAutoScroll);
    scroller.addEventListener("click", stopAutoScroll);
  }
}

function exit1ClickHandler(event) {
  if(SHOW_CONSOLE_LOGS) { console.log(clickTag1Label); }
  Enabler.exit(clickTag1Label, clickTag1URL);
}

function exit2ClickHandler(event) {
  if(SHOW_CONSOLE_LOGS) { console.log(clickTag2Label); }
  Enabler.exit(clickTag2Label, clickTag2URL);
}



//----------------------------------------------
// Helper Methods
//----------------------------------------------
function getTranslateY(element) {
  var style       = window.getComputedStyle(element);
  var matrix      = new WebKitCSSMatrix(style.webkitTransform);
  var translateY  = matrix.m42;

  return translateY;
}

function adTimer() {
  duration++;
  if(SHOW_CONSOLE_LOGS) { console.log("Ad Duration: ", duration/10); }
}

function endAdTimer() {
  clearInterval(durationInterval);
  if(SHOW_CONSOLE_LOGS) { console.log(""); }
  if(SHOW_CONSOLE_LOGS) { console.log("--------------------------------"); }
  if(SHOW_CONSOLE_LOGS) { console.log("Total Ad Duration: ", duration/10); }
  if(SHOW_CONSOLE_LOGS) { console.log("--------------------------------"); }
  if(SHOW_CONSOLE_LOGS) { console.log(""); }
}

function autoScroll() {
  // only autoScroll one time
  // add a mutex boolean for the cancel event listener
  if(CURRENT_PLAY_COUNT > 1 || ALLOW_AUTO_SCROLL == false) {
    return false;
  }

  var endPosition = ((0 - (scrollerContent.offsetHeight - autoScrollOffset)) + scrollerMask.offsetHeight);
  isi.scrollTo(0, endPosition, autoScrollSpeed, {
    // simple linear easing function
    style: 'cubic-bezier(0,0,1,1)',
    fn: function (k) { return k; }
  });

  // Stop auto scroll ater 30secs
  // window.setTimeout(stopAutoScroll, 30000);
  // isi = gsap.to('#scrollerMask', { duration: autoScrollSpeed, scrollTo: (endPosition*-1), ease: "linear" scrub: true });
}


function clear(elements, delay) {
  for (var i = 0, elementsLength = elements.length; i < elementsLength; i++) {
    TweenLite.to(elements[i], 0.5, {opacity: 0, delay: delay, onComplete: function() {
      hideElements(elements[i]);
    }});
  }
}

function hideElements(elements) {
  if (!Array.isArray(elements)) {
    elements = [elements];
  }

  for (var i = 0, elementsLength = elements.length; i < elementsLength; i++) {
    var element = elements[i];

    if (element) {
      if (element.className.length > 0) {
        element.className += ' hidden';
      } else {
        element.className += 'hidden';
      }

      element.style.display     = 'none';
      element.style.visibility  = 'hidden';
      element.style.opacity     = 0;
    }
  }
}

function showElements(elements) {
  if (!Array.isArray(elements)) {
    elements = [elements];
  }

  for (var i = 0, elementsLength = elements.length; i < elementsLength; i++) {
    var element = elements[i];
    if (element && element.style) {

      if (window.getComputedStyle(element, null).getPropertyValue("display").toLowerCase() == "none") {
        element.style.display   = 'block';
      }

      element.style.visibility  = 'visible';
      element.style.opacity     = 1;
      element.className         = element.className.split('hidden')[0];
    }
  }
}


function hasClass(el, className) {
    return el.classList ? el.classList.contains(className) : new RegExp('\\b'+ className+'\\b').test(el.className);
}

function addClass(el, className) {
    if (el.classList) el.classList.add(className);
    else if (!hasClass(el, className)) el.className += ' ' + className;
}

function removeClass(el, className) {
    if (el.classList) el.classList.remove(className);
    else el.className = el.className.replace(new RegExp('\\b'+ className+'\\b', 'g'), '');
}


//----------------------------------------------
// Init
//----------------------------------------------
window.onload = function() {
  buildVars();

  // only use bounce if it's not iOS
  var isIOS = (typeof bowser !== 'undefined' && bowser.ios);

  isi = new IScroll(scrollerMask, {
    mouseWheel: true,
    scrollbars: true,
    interactiveScrollbars: true,
    resizeScrollbars: false,
    click: true,
    bounce: (isIOS ? false : true)
  });

  if (Enabler.isInitialized()) {
    init();
  } else {
    Enabler.addEventListener(studio.events.StudioEvent.INIT, init);
  }
};


function init() {
  addListeners();

  if (pauseAtScene) {
    showScene(pauseAtScene);
  } else {
    animateScene1();
  }

  // move autoscroll to 3 seconds in
  // window.setTimeout(, 3000);

  // screenshot helper
  try {
    if((window.location.href).indexOf('screenshot=1') > -1) {
      window.arteric.screenshot.init();
    }
  } catch(err) {}
}

//----------------------------------------------
// For use with `screenshots.html`
// Can be omitted for production
//----------------------------------------------
var pauseAtScene = 1;
function showScene(sceneNumber) {
  pauseAtScene = sceneNumber;
  window['animateScene' + sceneNumber]();
}

//----------------------------------------------
// Size / Concept Specific
//----------------------------------------------
function animateScene1() {

  // this animation is written as a single timeline, in order to achieve full animation looping in a smarter way

  if(MASTER_TIMELINE == null) {
    MASTER_TIMELINE = gsap.timeline({ defaults: {ease: Power2.easeInOut} });
  }
  var tl = MASTER_TIMELINE;


  tl
    // BRING IN SCENE 1 TEXT 1 LINE AT A TIME
    .to( '.scene1Text .one', {
      opacity: 1,
      duration: .75
    }, 'start')
    .to( '.scene1Text .two', {
      opacity: 1,
      duration: .75
    })
    .to( '.scene1Text .three', {
      opacity: 1,
      duration: .75
    })

    // FADE TO BOLD -> THEN TURN LINE 2 GREEN
    .to('.scene1Text', {
      opacity: 0,
      duration: 0.5
    }, 'scene1')
    .to( '.scene1TextBold .one, .scene1TextBold .two, .scene1TextBold .three', {
      opacity: 1,
      duration: 0.5
    }, 'scene1')
    .to( '.blkCal', {
      opacity: 0,
      duration: 0.5
    }, 'scene1')
    .to( '.grnCal', {
      opacity: 1,
      duration: 0.5
    }, 'scene1')
    
    //FADE OUT SCENE 1
    .to( '.scene1TextBold, .grnCal', {
      opacity: 0,
      duration: .5,
      delay: 2.25
    })

    //FADE SCENE 1 TEXT INTO SCENE 2
    .to( '.scene2Text', {
      opacity: 1,
      duration: 0.5
    }, 'scene2FadeIn')
    .to( '.scene1TextBold', {
      opacity: 0,
      duration:0.5 
    }, 'scene2FadeIn')
    .to( '.bottleIcons', {
      opacity: 1,
      duration: .75
    }, 'scene2FadeIn')

    // + BUILD REST OF SCENE 2
    .to( '.scene2Text .one', {
      opacity: 1,
      duration: .75
    }, 'calendarFade')
    .to( '.scene2Text .two', {
      opacity: 1,
      duration: .75
    }, 'calendarFade+=0.75')
    .to( '.scene2Text .three', {
      opacity: 1,
      duration: .75
    }, 'calendarFade+=1.5')
    .to( '.scene2Text .four', {
      opacity: 1,
      duration: .75
    }, 'calendarFade+=2.25')
    .to( '.scene2Text .five', {
      opacity: 1,
      duration: .75
    }, 'calendarFade+=3')

    // SCENE 2 COPY TO ORANGE
    .to('.scene2Text', {
      opacity: 0,
      duration: 0.5
    }, 'scene2')
    .to( '.scene2TextBold .one, .scene2TextBold .two, .scene2TextBold .three, .scene2TextBold .four, .scene2TextBold .five', {
      opacity: 1,
      duration: 0.5
    }, 'scene2')

    // SCENE 3
    .to('.scene2TextBold, .bottleIcons, .logo', {
      opacity: 0,
      duration: .5,
      delay: 2.25
    })
    .to('#scene3', {
      opacity: 1,
      duration: .5
    })

    // FADE OUT SCENE 3 THEN BUILD SCENE 4
    .to('#scene3', {
      opacity: 0,
      duration: .5,
      delay: 5
    })
    .to( '.plainBubbles, .logo', {
      opacity: 1,
      duration: 0.75
    }, 'docFade')
    .to( '.scene4Text .one', {
      opacity: 1,
      duration: 0.75
    }, 'docFade+=.5')
    .to( '.scene4Text .two', {
      opacity: 1,
      duration: .75
    }, 'docFade+=1.25')
    .to( '.scene4Text .three', {
      opacity: 1,
      duration: .75
    }, 'docFade+=2')
    .to( '.scene4Text .four', {
      opacity: 1,
      duration: .75
    }, 'docFade+=2.75')
    .to('.scene4Text', {
      opacity: 0,
      duration: 0.5
    }, 'scene4')
    .to( '.scene4TextBold .one, .scene4TextBold .two, .scene4TextBold .three, .scene4TextBold .four', {
      opacity: 1,
      duration: 0.5,
    }, 'scene4')
    .to( '.plainBubbles', {
      opacity: 0,
      duration: 0.5
    }, 'scene4')
    .to( '.quoteBubbles', {
      opacity: 1,
      duration: 0.5
    }, 'scene4')
    .to('.btn', {
      opacity: 1,
      duration: .5,
      onComplete: autoScroll
    })
    
  tl.play();

}


//----------------------------------------------
// End
//----------------------------------------------

function checkLoop() {
console.log("check loop")
if(SHOW_CONSOLE_LOGS) { console.log('checkLoop : total duration of Timeline = ' + MASTER_TIMELINE.totalDuration()); }
CURRENT_PLAY_COUNT++;

if(CURRENT_PLAY_COUNT <= TOTAL_PLAY_COUNT) {
  
  // tween to prep for a repeat
  var repeaterTimeline = gsap.timeline({ 
    onComplete: function() {
      // when all done with the tweenPrep, repeat it again from scene1
      MASTER_TIMELINE.seek('start');
    }, 
    defaults: {ease: Power2.easeInOut} 
  });

  repeaterTimeline
    .delay(1.5)
    .to( ' #isiContainer, .logo, #scene4, .btn', {
      opacity: 0,
      duration: 1
    })
  ;

  if(SHOW_CONSOLE_LOGS) { console.log('repeater prep total duration = ' + repeaterTimeline.totalDuration()); }
}


}

// Purpose: to list any/all functions to reveal any hidden content for screenshots
var ScreenshotService = {

  init: function() {
      this.expandAd();
      this.movePIBar();
  },

  
  expandAd: function() {
      var ad = document.querySelector('#ad');
      ad.setAttribute('style','height: 100%; overflow: visible');

      // stop the scrolling
      // isi.scrollTo(0, currentScrollPosition, 0);
      isi.scrollTo(0, 0, 200);

      // expand the scroller visibility
      scrollerMask.setAttribute('style','overflow: visible');

      // measure the height of the full ad and set the ad element height to THAT
      var isiHeight = scrollerContent.scrollHeight;
      var isiHeaderHeight = document.querySelector('#scrollerContainer h1.caps').clientHeight;
      var totalHeight = isiHeight + animation.clientHeight + isiHeaderHeight;
      ad.setAttribute('style','height: '+ totalHeight +'px; overflow: visible');
  },


  movePIBar: function() {
    var pibar = document.querySelector('#pi');
    pibar.setAttribute('style','top: 100%');
  }

};


// create window.arteric namespace, if needed
if(!window.arteric) {
  window.arteric = {};
}

// expose the service to the window.arteric namespace
window.arteric['screenshot'] = ScreenshotService;


// export the service to the any module requiring it
// module.exports = ScreenshotService;


// run the thing
// window.arteric.screenshot.init();
